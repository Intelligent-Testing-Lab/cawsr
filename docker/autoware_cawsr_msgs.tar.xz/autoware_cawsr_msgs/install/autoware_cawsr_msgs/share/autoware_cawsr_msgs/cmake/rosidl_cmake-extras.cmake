# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(autoware_cawsr_msgs_IDL_FILES "msg/AutowareRestart.idl;msg/AutowareShutdown.idl;srv/AutowareTick.idl")
set(autoware_cawsr_msgs_INTERFACE_FILES "msg/AutowareRestart.msg;msg/AutowareShutdown.msg;srv/AutowareTick.srv;srv/AutowareTick_Request.msg;srv/AutowareTick_Response.msg")

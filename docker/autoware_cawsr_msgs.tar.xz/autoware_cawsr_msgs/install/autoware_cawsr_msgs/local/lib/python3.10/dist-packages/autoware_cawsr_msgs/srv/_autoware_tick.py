# generated from rosidl_generator_py/resource/_idl.py.em
# with input from autoware_cawsr_msgs:srv/AutowareTick.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_AutowareTick_Request(type):
    """Metaclass of message 'AutowareTick_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('autoware_cawsr_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'autoware_cawsr_msgs.srv.AutowareTick_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__autoware_tick__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__autoware_tick__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__autoware_tick__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__autoware_tick__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__autoware_tick__request

            from std_msgs.msg import Header
            if Header.__class__._TYPE_SUPPORT is None:
                Header.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class AutowareTick_Request(metaclass=Metaclass_AutowareTick_Request):
    """Message class 'AutowareTick_Request'."""

    __slots__ = [
        '_header',
    ]

    _fields_and_field_types = {
        'header': 'std_msgs/Header',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Header'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from std_msgs.msg import Header
        self.header = kwargs.get('header', Header())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.header != other.header:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def header(self):
        """Message field 'header'."""
        return self._header

    @header.setter
    def header(self, value):
        if __debug__:
            from std_msgs.msg import Header
            assert \
                isinstance(value, Header), \
                "The 'header' field must be a sub message of type 'Header'"
        self._header = value


# Import statements for member types

# already imported above
# import builtins

import math  # noqa: E402, I100

# already imported above
# import rosidl_parser.definition


class Metaclass_AutowareTick_Response(type):
    """Metaclass of message 'AutowareTick_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('autoware_cawsr_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'autoware_cawsr_msgs.srv.AutowareTick_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__autoware_tick__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__autoware_tick__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__autoware_tick__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__autoware_tick__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__autoware_tick__response

            from std_msgs.msg import Header
            if Header.__class__._TYPE_SUPPORT is None:
                Header.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class AutowareTick_Response(metaclass=Metaclass_AutowareTick_Response):
    """Message class 'AutowareTick_Response'."""

    __slots__ = [
        '_header',
        '_snapshot',
        '_state',
        '_sensor',
        '_control',
        '_agent_total',
    ]

    _fields_and_field_types = {
        'header': 'std_msgs/Header',
        'snapshot': 'float',
        'state': 'float',
        'sensor': 'float',
        'control': 'float',
        'agent_total': 'float',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Header'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from std_msgs.msg import Header
        self.header = kwargs.get('header', Header())
        self.snapshot = kwargs.get('snapshot', float())
        self.state = kwargs.get('state', float())
        self.sensor = kwargs.get('sensor', float())
        self.control = kwargs.get('control', float())
        self.agent_total = kwargs.get('agent_total', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.header != other.header:
            return False
        if self.snapshot != other.snapshot:
            return False
        if self.state != other.state:
            return False
        if self.sensor != other.sensor:
            return False
        if self.control != other.control:
            return False
        if self.agent_total != other.agent_total:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def header(self):
        """Message field 'header'."""
        return self._header

    @header.setter
    def header(self, value):
        if __debug__:
            from std_msgs.msg import Header
            assert \
                isinstance(value, Header), \
                "The 'header' field must be a sub message of type 'Header'"
        self._header = value

    @builtins.property
    def snapshot(self):
        """Message field 'snapshot'."""
        return self._snapshot

    @snapshot.setter
    def snapshot(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'snapshot' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'snapshot' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._snapshot = value

    @builtins.property
    def state(self):
        """Message field 'state'."""
        return self._state

    @state.setter
    def state(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'state' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'state' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._state = value

    @builtins.property
    def sensor(self):
        """Message field 'sensor'."""
        return self._sensor

    @sensor.setter
    def sensor(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'sensor' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'sensor' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._sensor = value

    @builtins.property
    def control(self):
        """Message field 'control'."""
        return self._control

    @control.setter
    def control(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'control' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'control' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._control = value

    @builtins.property
    def agent_total(self):
        """Message field 'agent_total'."""
        return self._agent_total

    @agent_total.setter
    def agent_total(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'agent_total' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'agent_total' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._agent_total = value


class Metaclass_AutowareTick(type):
    """Metaclass of service 'AutowareTick'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('autoware_cawsr_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'autoware_cawsr_msgs.srv.AutowareTick')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__autoware_tick

            from autoware_cawsr_msgs.srv import _autoware_tick
            if _autoware_tick.Metaclass_AutowareTick_Request._TYPE_SUPPORT is None:
                _autoware_tick.Metaclass_AutowareTick_Request.__import_type_support__()
            if _autoware_tick.Metaclass_AutowareTick_Response._TYPE_SUPPORT is None:
                _autoware_tick.Metaclass_AutowareTick_Response.__import_type_support__()


class AutowareTick(metaclass=Metaclass_AutowareTick):
    from autoware_cawsr_msgs.srv._autoware_tick import AutowareTick_Request as Request
    from autoware_cawsr_msgs.srv._autoware_tick import AutowareTick_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')

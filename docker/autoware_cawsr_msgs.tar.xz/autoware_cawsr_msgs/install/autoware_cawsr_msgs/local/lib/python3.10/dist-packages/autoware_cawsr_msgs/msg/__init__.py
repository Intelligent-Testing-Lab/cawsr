from autoware_cawsr_msgs.msg._autoware_restart import AutowareRestart  # noqa: F401
from autoware_cawsr_msgs.msg._autoware_shutdown import AutowareShutdown  # noqa: F401

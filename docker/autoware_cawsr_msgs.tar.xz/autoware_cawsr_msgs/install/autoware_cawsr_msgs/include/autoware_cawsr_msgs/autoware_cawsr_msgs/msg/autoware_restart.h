// generated from rosidl_generator_c/resource/idl.h.em
// with input from autoware_cawsr_msgs:msg/AutowareRestart.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__AUTOWARE_RESTART_H_
#define AUTOWARE_CAWSR_MSGS__MSG__AUTOWARE_RESTART_H_

#include "autoware_cawsr_msgs/msg/detail/autoware_restart__struct.h"
#include "autoware_cawsr_msgs/msg/detail/autoware_restart__functions.h"
#include "autoware_cawsr_msgs/msg/detail/autoware_restart__type_support.h"

#endif  // AUTOWARE_CAWSR_MSGS__MSG__AUTOWARE_RESTART_H_

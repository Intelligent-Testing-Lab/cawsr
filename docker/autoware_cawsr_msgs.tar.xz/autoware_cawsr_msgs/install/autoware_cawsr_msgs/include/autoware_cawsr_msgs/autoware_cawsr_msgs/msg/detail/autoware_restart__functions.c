// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from autoware_cawsr_msgs:msg/AutowareRestart.idl
// generated code does not contain a copyright notice
#include "autoware_cawsr_msgs/msg/detail/autoware_restart__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `carla_map`
#include "rosidl_runtime_c/string_functions.h"

bool
autoware_cawsr_msgs__msg__AutowareRestart__init(autoware_cawsr_msgs__msg__AutowareRestart * msg)
{
  if (!msg) {
    return false;
  }
  // carla_map
  if (!rosidl_runtime_c__String__init(&msg->carla_map)) {
    autoware_cawsr_msgs__msg__AutowareRestart__fini(msg);
    return false;
  }
  return true;
}

void
autoware_cawsr_msgs__msg__AutowareRestart__fini(autoware_cawsr_msgs__msg__AutowareRestart * msg)
{
  if (!msg) {
    return;
  }
  // carla_map
  rosidl_runtime_c__String__fini(&msg->carla_map);
}

bool
autoware_cawsr_msgs__msg__AutowareRestart__are_equal(const autoware_cawsr_msgs__msg__AutowareRestart * lhs, const autoware_cawsr_msgs__msg__AutowareRestart * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // carla_map
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->carla_map), &(rhs->carla_map)))
  {
    return false;
  }
  return true;
}

bool
autoware_cawsr_msgs__msg__AutowareRestart__copy(
  const autoware_cawsr_msgs__msg__AutowareRestart * input,
  autoware_cawsr_msgs__msg__AutowareRestart * output)
{
  if (!input || !output) {
    return false;
  }
  // carla_map
  if (!rosidl_runtime_c__String__copy(
      &(input->carla_map), &(output->carla_map)))
  {
    return false;
  }
  return true;
}

autoware_cawsr_msgs__msg__AutowareRestart *
autoware_cawsr_msgs__msg__AutowareRestart__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autoware_cawsr_msgs__msg__AutowareRestart * msg = (autoware_cawsr_msgs__msg__AutowareRestart *)allocator.allocate(sizeof(autoware_cawsr_msgs__msg__AutowareRestart), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(autoware_cawsr_msgs__msg__AutowareRestart));
  bool success = autoware_cawsr_msgs__msg__AutowareRestart__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
autoware_cawsr_msgs__msg__AutowareRestart__destroy(autoware_cawsr_msgs__msg__AutowareRestart * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    autoware_cawsr_msgs__msg__AutowareRestart__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
autoware_cawsr_msgs__msg__AutowareRestart__Sequence__init(autoware_cawsr_msgs__msg__AutowareRestart__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autoware_cawsr_msgs__msg__AutowareRestart * data = NULL;

  if (size) {
    data = (autoware_cawsr_msgs__msg__AutowareRestart *)allocator.zero_allocate(size, sizeof(autoware_cawsr_msgs__msg__AutowareRestart), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = autoware_cawsr_msgs__msg__AutowareRestart__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        autoware_cawsr_msgs__msg__AutowareRestart__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
autoware_cawsr_msgs__msg__AutowareRestart__Sequence__fini(autoware_cawsr_msgs__msg__AutowareRestart__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      autoware_cawsr_msgs__msg__AutowareRestart__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

autoware_cawsr_msgs__msg__AutowareRestart__Sequence *
autoware_cawsr_msgs__msg__AutowareRestart__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autoware_cawsr_msgs__msg__AutowareRestart__Sequence * array = (autoware_cawsr_msgs__msg__AutowareRestart__Sequence *)allocator.allocate(sizeof(autoware_cawsr_msgs__msg__AutowareRestart__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = autoware_cawsr_msgs__msg__AutowareRestart__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
autoware_cawsr_msgs__msg__AutowareRestart__Sequence__destroy(autoware_cawsr_msgs__msg__AutowareRestart__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    autoware_cawsr_msgs__msg__AutowareRestart__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
autoware_cawsr_msgs__msg__AutowareRestart__Sequence__are_equal(const autoware_cawsr_msgs__msg__AutowareRestart__Sequence * lhs, const autoware_cawsr_msgs__msg__AutowareRestart__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!autoware_cawsr_msgs__msg__AutowareRestart__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
autoware_cawsr_msgs__msg__AutowareRestart__Sequence__copy(
  const autoware_cawsr_msgs__msg__AutowareRestart__Sequence * input,
  autoware_cawsr_msgs__msg__AutowareRestart__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(autoware_cawsr_msgs__msg__AutowareRestart);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    autoware_cawsr_msgs__msg__AutowareRestart * data =
      (autoware_cawsr_msgs__msg__AutowareRestart *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!autoware_cawsr_msgs__msg__AutowareRestart__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          autoware_cawsr_msgs__msg__AutowareRestart__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!autoware_cawsr_msgs__msg__AutowareRestart__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}

// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autoware_cawsr_msgs:srv/AutowareTick.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__STRUCT_H_
#define AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in srv/AutowareTick in the package autoware_cawsr_msgs.
typedef struct autoware_cawsr_msgs__srv__AutowareTick_Request
{
  std_msgs__msg__Header header;
} autoware_cawsr_msgs__srv__AutowareTick_Request;

// Struct for a sequence of autoware_cawsr_msgs__srv__AutowareTick_Request.
typedef struct autoware_cawsr_msgs__srv__AutowareTick_Request__Sequence
{
  autoware_cawsr_msgs__srv__AutowareTick_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autoware_cawsr_msgs__srv__AutowareTick_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'header'
// already included above
// #include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in srv/AutowareTick in the package autoware_cawsr_msgs.
typedef struct autoware_cawsr_msgs__srv__AutowareTick_Response
{
  std_msgs__msg__Header header;
  float snapshot;
  float state;
  float sensor;
  float control;
  float agent_total;
} autoware_cawsr_msgs__srv__AutowareTick_Response;

// Struct for a sequence of autoware_cawsr_msgs__srv__AutowareTick_Response.
typedef struct autoware_cawsr_msgs__srv__AutowareTick_Response__Sequence
{
  autoware_cawsr_msgs__srv__AutowareTick_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autoware_cawsr_msgs__srv__AutowareTick_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__STRUCT_H_

// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from autoware_cawsr_msgs:srv/AutowareTick.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__TRAITS_HPP_
#define AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "autoware_cawsr_msgs/srv/detail/autoware_tick__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace autoware_cawsr_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const AutowareTick_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const AutowareTick_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const AutowareTick_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace autoware_cawsr_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autoware_cawsr_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autoware_cawsr_msgs::srv::AutowareTick_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  autoware_cawsr_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autoware_cawsr_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const autoware_cawsr_msgs::srv::AutowareTick_Request & msg)
{
  return autoware_cawsr_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<autoware_cawsr_msgs::srv::AutowareTick_Request>()
{
  return "autoware_cawsr_msgs::srv::AutowareTick_Request";
}

template<>
inline const char * name<autoware_cawsr_msgs::srv::AutowareTick_Request>()
{
  return "autoware_cawsr_msgs/srv/AutowareTick_Request";
}

template<>
struct has_fixed_size<autoware_cawsr_msgs::srv::AutowareTick_Request>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<autoware_cawsr_msgs::srv::AutowareTick_Request>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<autoware_cawsr_msgs::srv::AutowareTick_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'header'
// already included above
// #include "std_msgs/msg/detail/header__traits.hpp"

namespace autoware_cawsr_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const AutowareTick_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: snapshot
  {
    out << "snapshot: ";
    rosidl_generator_traits::value_to_yaml(msg.snapshot, out);
    out << ", ";
  }

  // member: state
  {
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
    out << ", ";
  }

  // member: sensor
  {
    out << "sensor: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor, out);
    out << ", ";
  }

  // member: control
  {
    out << "control: ";
    rosidl_generator_traits::value_to_yaml(msg.control, out);
    out << ", ";
  }

  // member: agent_total
  {
    out << "agent_total: ";
    rosidl_generator_traits::value_to_yaml(msg.agent_total, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const AutowareTick_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: snapshot
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "snapshot: ";
    rosidl_generator_traits::value_to_yaml(msg.snapshot, out);
    out << "\n";
  }

  // member: state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
    out << "\n";
  }

  // member: sensor
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sensor: ";
    rosidl_generator_traits::value_to_yaml(msg.sensor, out);
    out << "\n";
  }

  // member: control
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control: ";
    rosidl_generator_traits::value_to_yaml(msg.control, out);
    out << "\n";
  }

  // member: agent_total
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "agent_total: ";
    rosidl_generator_traits::value_to_yaml(msg.agent_total, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const AutowareTick_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace autoware_cawsr_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autoware_cawsr_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autoware_cawsr_msgs::srv::AutowareTick_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  autoware_cawsr_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autoware_cawsr_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const autoware_cawsr_msgs::srv::AutowareTick_Response & msg)
{
  return autoware_cawsr_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<autoware_cawsr_msgs::srv::AutowareTick_Response>()
{
  return "autoware_cawsr_msgs::srv::AutowareTick_Response";
}

template<>
inline const char * name<autoware_cawsr_msgs::srv::AutowareTick_Response>()
{
  return "autoware_cawsr_msgs/srv/AutowareTick_Response";
}

template<>
struct has_fixed_size<autoware_cawsr_msgs::srv::AutowareTick_Response>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<autoware_cawsr_msgs::srv::AutowareTick_Response>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<autoware_cawsr_msgs::srv::AutowareTick_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<autoware_cawsr_msgs::srv::AutowareTick>()
{
  return "autoware_cawsr_msgs::srv::AutowareTick";
}

template<>
inline const char * name<autoware_cawsr_msgs::srv::AutowareTick>()
{
  return "autoware_cawsr_msgs/srv/AutowareTick";
}

template<>
struct has_fixed_size<autoware_cawsr_msgs::srv::AutowareTick>
  : std::integral_constant<
    bool,
    has_fixed_size<autoware_cawsr_msgs::srv::AutowareTick_Request>::value &&
    has_fixed_size<autoware_cawsr_msgs::srv::AutowareTick_Response>::value
  >
{
};

template<>
struct has_bounded_size<autoware_cawsr_msgs::srv::AutowareTick>
  : std::integral_constant<
    bool,
    has_bounded_size<autoware_cawsr_msgs::srv::AutowareTick_Request>::value &&
    has_bounded_size<autoware_cawsr_msgs::srv::AutowareTick_Response>::value
  >
{
};

template<>
struct is_service<autoware_cawsr_msgs::srv::AutowareTick>
  : std::true_type
{
};

template<>
struct is_service_request<autoware_cawsr_msgs::srv::AutowareTick_Request>
  : std::true_type
{
};

template<>
struct is_service_response<autoware_cawsr_msgs::srv::AutowareTick_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__TRAITS_HPP_

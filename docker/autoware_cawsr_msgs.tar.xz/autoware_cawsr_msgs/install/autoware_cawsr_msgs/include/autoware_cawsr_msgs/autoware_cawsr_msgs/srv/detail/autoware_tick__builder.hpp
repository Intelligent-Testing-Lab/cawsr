// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autoware_cawsr_msgs:srv/AutowareTick.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__BUILDER_HPP_
#define AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autoware_cawsr_msgs/srv/detail/autoware_tick__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autoware_cawsr_msgs
{

namespace srv
{

namespace builder
{

class Init_AutowareTick_Request_header
{
public:
  Init_AutowareTick_Request_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::autoware_cawsr_msgs::srv::AutowareTick_Request header(::autoware_cawsr_msgs::srv::AutowareTick_Request::_header_type arg)
  {
    msg_.header = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autoware_cawsr_msgs::srv::AutowareTick_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::autoware_cawsr_msgs::srv::AutowareTick_Request>()
{
  return autoware_cawsr_msgs::srv::builder::Init_AutowareTick_Request_header();
}

}  // namespace autoware_cawsr_msgs


namespace autoware_cawsr_msgs
{

namespace srv
{

namespace builder
{

class Init_AutowareTick_Response_agent_total
{
public:
  explicit Init_AutowareTick_Response_agent_total(::autoware_cawsr_msgs::srv::AutowareTick_Response & msg)
  : msg_(msg)
  {}
  ::autoware_cawsr_msgs::srv::AutowareTick_Response agent_total(::autoware_cawsr_msgs::srv::AutowareTick_Response::_agent_total_type arg)
  {
    msg_.agent_total = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autoware_cawsr_msgs::srv::AutowareTick_Response msg_;
};

class Init_AutowareTick_Response_control
{
public:
  explicit Init_AutowareTick_Response_control(::autoware_cawsr_msgs::srv::AutowareTick_Response & msg)
  : msg_(msg)
  {}
  Init_AutowareTick_Response_agent_total control(::autoware_cawsr_msgs::srv::AutowareTick_Response::_control_type arg)
  {
    msg_.control = std::move(arg);
    return Init_AutowareTick_Response_agent_total(msg_);
  }

private:
  ::autoware_cawsr_msgs::srv::AutowareTick_Response msg_;
};

class Init_AutowareTick_Response_sensor
{
public:
  explicit Init_AutowareTick_Response_sensor(::autoware_cawsr_msgs::srv::AutowareTick_Response & msg)
  : msg_(msg)
  {}
  Init_AutowareTick_Response_control sensor(::autoware_cawsr_msgs::srv::AutowareTick_Response::_sensor_type arg)
  {
    msg_.sensor = std::move(arg);
    return Init_AutowareTick_Response_control(msg_);
  }

private:
  ::autoware_cawsr_msgs::srv::AutowareTick_Response msg_;
};

class Init_AutowareTick_Response_state
{
public:
  explicit Init_AutowareTick_Response_state(::autoware_cawsr_msgs::srv::AutowareTick_Response & msg)
  : msg_(msg)
  {}
  Init_AutowareTick_Response_sensor state(::autoware_cawsr_msgs::srv::AutowareTick_Response::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_AutowareTick_Response_sensor(msg_);
  }

private:
  ::autoware_cawsr_msgs::srv::AutowareTick_Response msg_;
};

class Init_AutowareTick_Response_snapshot
{
public:
  explicit Init_AutowareTick_Response_snapshot(::autoware_cawsr_msgs::srv::AutowareTick_Response & msg)
  : msg_(msg)
  {}
  Init_AutowareTick_Response_state snapshot(::autoware_cawsr_msgs::srv::AutowareTick_Response::_snapshot_type arg)
  {
    msg_.snapshot = std::move(arg);
    return Init_AutowareTick_Response_state(msg_);
  }

private:
  ::autoware_cawsr_msgs::srv::AutowareTick_Response msg_;
};

class Init_AutowareTick_Response_header
{
public:
  Init_AutowareTick_Response_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AutowareTick_Response_snapshot header(::autoware_cawsr_msgs::srv::AutowareTick_Response::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_AutowareTick_Response_snapshot(msg_);
  }

private:
  ::autoware_cawsr_msgs::srv::AutowareTick_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::autoware_cawsr_msgs::srv::AutowareTick_Response>()
{
  return autoware_cawsr_msgs::srv::builder::Init_AutowareTick_Response_header();
}

}  // namespace autoware_cawsr_msgs

#endif  // AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__BUILDER_HPP_

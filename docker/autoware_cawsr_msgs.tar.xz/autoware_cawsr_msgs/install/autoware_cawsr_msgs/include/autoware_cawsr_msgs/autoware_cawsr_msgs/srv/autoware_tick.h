// generated from rosidl_generator_c/resource/idl.h.em
// with input from autoware_cawsr_msgs:srv/AutowareTick.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__SRV__AUTOWARE_TICK_H_
#define AUTOWARE_CAWSR_MSGS__SRV__AUTOWARE_TICK_H_

#include "autoware_cawsr_msgs/srv/detail/autoware_tick__struct.h"
#include "autoware_cawsr_msgs/srv/detail/autoware_tick__functions.h"
#include "autoware_cawsr_msgs/srv/detail/autoware_tick__type_support.h"

#endif  // AUTOWARE_CAWSR_MSGS__SRV__AUTOWARE_TICK_H_

// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__AUTOWARE_SHUTDOWN_HPP_
#define AUTOWARE_CAWSR_MSGS__MSG__AUTOWARE_SHUTDOWN_HPP_

#include "autoware_cawsr_msgs/msg/detail/autoware_shutdown__struct.hpp"
#include "autoware_cawsr_msgs/msg/detail/autoware_shutdown__builder.hpp"
#include "autoware_cawsr_msgs/msg/detail/autoware_shutdown__traits.hpp"
#include "autoware_cawsr_msgs/msg/detail/autoware_shutdown__type_support.hpp"

#endif  // AUTOWARE_CAWSR_MSGS__MSG__AUTOWARE_SHUTDOWN_HPP_

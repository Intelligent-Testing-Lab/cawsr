// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autoware_cawsr_msgs:msg/AutowareRestart.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_RESTART__BUILDER_HPP_
#define AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_RESTART__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autoware_cawsr_msgs/msg/detail/autoware_restart__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autoware_cawsr_msgs
{

namespace msg
{

namespace builder
{

class Init_AutowareRestart_carla_map
{
public:
  Init_AutowareRestart_carla_map()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::autoware_cawsr_msgs::msg::AutowareRestart carla_map(::autoware_cawsr_msgs::msg::AutowareRestart::_carla_map_type arg)
  {
    msg_.carla_map = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autoware_cawsr_msgs::msg::AutowareRestart msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::autoware_cawsr_msgs::msg::AutowareRestart>()
{
  return autoware_cawsr_msgs::msg::builder::Init_AutowareRestart_carla_map();
}

}  // namespace autoware_cawsr_msgs

#endif  // AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_RESTART__BUILDER_HPP_

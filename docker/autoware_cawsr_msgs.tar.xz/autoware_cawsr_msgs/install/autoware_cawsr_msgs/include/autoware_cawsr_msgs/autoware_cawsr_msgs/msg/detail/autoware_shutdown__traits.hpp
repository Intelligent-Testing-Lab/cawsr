// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from autoware_cawsr_msgs:msg/AutowareShutdown.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__TRAITS_HPP_
#define AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "autoware_cawsr_msgs/msg/detail/autoware_shutdown__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace autoware_cawsr_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const AutowareShutdown & msg,
  std::ostream & out)
{
  out << "{";
  // member: carla_map
  {
    out << "carla_map: ";
    rosidl_generator_traits::value_to_yaml(msg.carla_map, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const AutowareShutdown & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: carla_map
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "carla_map: ";
    rosidl_generator_traits::value_to_yaml(msg.carla_map, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const AutowareShutdown & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace autoware_cawsr_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autoware_cawsr_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autoware_cawsr_msgs::msg::AutowareShutdown & msg,
  std::ostream & out, size_t indentation = 0)
{
  autoware_cawsr_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autoware_cawsr_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const autoware_cawsr_msgs::msg::AutowareShutdown & msg)
{
  return autoware_cawsr_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<autoware_cawsr_msgs::msg::AutowareShutdown>()
{
  return "autoware_cawsr_msgs::msg::AutowareShutdown";
}

template<>
inline const char * name<autoware_cawsr_msgs::msg::AutowareShutdown>()
{
  return "autoware_cawsr_msgs/msg/AutowareShutdown";
}

template<>
struct has_fixed_size<autoware_cawsr_msgs::msg::AutowareShutdown>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<autoware_cawsr_msgs::msg::AutowareShutdown>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<autoware_cawsr_msgs::msg::AutowareShutdown>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__TRAITS_HPP_

// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from autoware_cawsr_msgs:msg/AutowareShutdown.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__STRUCT_HPP_
#define AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__autoware_cawsr_msgs__msg__AutowareShutdown __attribute__((deprecated))
#else
# define DEPRECATED__autoware_cawsr_msgs__msg__AutowareShutdown __declspec(deprecated)
#endif

namespace autoware_cawsr_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AutowareShutdown_
{
  using Type = AutowareShutdown_<ContainerAllocator>;

  explicit AutowareShutdown_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->carla_map = "";
    }
  }

  explicit AutowareShutdown_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : carla_map(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->carla_map = "";
    }
  }

  // field types and members
  using _carla_map_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _carla_map_type carla_map;

  // setters for named parameter idiom
  Type & set__carla_map(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->carla_map = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator> *;
  using ConstRawPtr =
    const autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__autoware_cawsr_msgs__msg__AutowareShutdown
    std::shared_ptr<autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__autoware_cawsr_msgs__msg__AutowareShutdown
    std::shared_ptr<autoware_cawsr_msgs::msg::AutowareShutdown_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AutowareShutdown_ & other) const
  {
    if (this->carla_map != other.carla_map) {
      return false;
    }
    return true;
  }
  bool operator!=(const AutowareShutdown_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AutowareShutdown_

// alias to use template instance with default allocator
using AutowareShutdown =
  autoware_cawsr_msgs::msg::AutowareShutdown_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace autoware_cawsr_msgs

#endif  // AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__STRUCT_HPP_

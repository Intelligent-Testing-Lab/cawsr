// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from autoware_cawsr_msgs:srv/AutowareTick.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "autoware_cawsr_msgs/srv/detail/autoware_tick__rosidl_typesupport_introspection_c.h"
#include "autoware_cawsr_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "autoware_cawsr_msgs/srv/detail/autoware_tick__functions.h"
#include "autoware_cawsr_msgs/srv/detail/autoware_tick__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  autoware_cawsr_msgs__srv__AutowareTick_Request__init(message_memory);
}

void autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_fini_function(void * message_memory)
{
  autoware_cawsr_msgs__srv__AutowareTick_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_message_member_array[1] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autoware_cawsr_msgs__srv__AutowareTick_Request, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_message_members = {
  "autoware_cawsr_msgs__srv",  // message namespace
  "AutowareTick_Request",  // message name
  1,  // number of fields
  sizeof(autoware_cawsr_msgs__srv__AutowareTick_Request),
  autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_message_member_array,  // message members
  autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_message_type_support_handle = {
  0,
  &autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_autoware_cawsr_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autoware_cawsr_msgs, srv, AutowareTick_Request)() {
  autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_message_type_support_handle.typesupport_identifier) {
    autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &autoware_cawsr_msgs__srv__AutowareTick_Request__rosidl_typesupport_introspection_c__AutowareTick_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "autoware_cawsr_msgs/srv/detail/autoware_tick__rosidl_typesupport_introspection_c.h"
// already included above
// #include "autoware_cawsr_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "autoware_cawsr_msgs/srv/detail/autoware_tick__functions.h"
// already included above
// #include "autoware_cawsr_msgs/srv/detail/autoware_tick__struct.h"


// Include directives for member types
// Member `header`
// already included above
// #include "std_msgs/msg/header.h"
// Member `header`
// already included above
// #include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  autoware_cawsr_msgs__srv__AutowareTick_Response__init(message_memory);
}

void autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_fini_function(void * message_memory)
{
  autoware_cawsr_msgs__srv__AutowareTick_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_message_member_array[6] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autoware_cawsr_msgs__srv__AutowareTick_Response, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "snapshot",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autoware_cawsr_msgs__srv__AutowareTick_Response, snapshot),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "state",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autoware_cawsr_msgs__srv__AutowareTick_Response, state),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "sensor",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autoware_cawsr_msgs__srv__AutowareTick_Response, sensor),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "control",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autoware_cawsr_msgs__srv__AutowareTick_Response, control),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "agent_total",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autoware_cawsr_msgs__srv__AutowareTick_Response, agent_total),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_message_members = {
  "autoware_cawsr_msgs__srv",  // message namespace
  "AutowareTick_Response",  // message name
  6,  // number of fields
  sizeof(autoware_cawsr_msgs__srv__AutowareTick_Response),
  autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_message_member_array,  // message members
  autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_message_type_support_handle = {
  0,
  &autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_autoware_cawsr_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autoware_cawsr_msgs, srv, AutowareTick_Response)() {
  autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_message_type_support_handle.typesupport_identifier) {
    autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &autoware_cawsr_msgs__srv__AutowareTick_Response__rosidl_typesupport_introspection_c__AutowareTick_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "autoware_cawsr_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "autoware_cawsr_msgs/srv/detail/autoware_tick__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers autoware_cawsr_msgs__srv__detail__autoware_tick__rosidl_typesupport_introspection_c__AutowareTick_service_members = {
  "autoware_cawsr_msgs__srv",  // service namespace
  "AutowareTick",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // autoware_cawsr_msgs__srv__detail__autoware_tick__rosidl_typesupport_introspection_c__AutowareTick_Request_message_type_support_handle,
  NULL  // response message
  // autoware_cawsr_msgs__srv__detail__autoware_tick__rosidl_typesupport_introspection_c__AutowareTick_Response_message_type_support_handle
};

static rosidl_service_type_support_t autoware_cawsr_msgs__srv__detail__autoware_tick__rosidl_typesupport_introspection_c__AutowareTick_service_type_support_handle = {
  0,
  &autoware_cawsr_msgs__srv__detail__autoware_tick__rosidl_typesupport_introspection_c__AutowareTick_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autoware_cawsr_msgs, srv, AutowareTick_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autoware_cawsr_msgs, srv, AutowareTick_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_autoware_cawsr_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autoware_cawsr_msgs, srv, AutowareTick)() {
  if (!autoware_cawsr_msgs__srv__detail__autoware_tick__rosidl_typesupport_introspection_c__AutowareTick_service_type_support_handle.typesupport_identifier) {
    autoware_cawsr_msgs__srv__detail__autoware_tick__rosidl_typesupport_introspection_c__AutowareTick_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)autoware_cawsr_msgs__srv__detail__autoware_tick__rosidl_typesupport_introspection_c__AutowareTick_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autoware_cawsr_msgs, srv, AutowareTick_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autoware_cawsr_msgs, srv, AutowareTick_Response)()->data;
  }

  return &autoware_cawsr_msgs__srv__detail__autoware_tick__rosidl_typesupport_introspection_c__AutowareTick_service_type_support_handle;
}

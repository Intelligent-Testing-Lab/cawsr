// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__AUTOWARE_RESTART_HPP_
#define AUTOWARE_CAWSR_MSGS__MSG__AUTOWARE_RESTART_HPP_

#include "autoware_cawsr_msgs/msg/detail/autoware_restart__struct.hpp"
#include "autoware_cawsr_msgs/msg/detail/autoware_restart__builder.hpp"
#include "autoware_cawsr_msgs/msg/detail/autoware_restart__traits.hpp"
#include "autoware_cawsr_msgs/msg/detail/autoware_restart__type_support.hpp"

#endif  // AUTOWARE_CAWSR_MSGS__MSG__AUTOWARE_RESTART_HPP_

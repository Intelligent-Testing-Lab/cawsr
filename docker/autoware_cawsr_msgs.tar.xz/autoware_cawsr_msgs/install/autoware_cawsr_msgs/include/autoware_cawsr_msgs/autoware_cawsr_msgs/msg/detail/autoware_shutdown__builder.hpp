// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autoware_cawsr_msgs:msg/AutowareShutdown.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__BUILDER_HPP_
#define AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autoware_cawsr_msgs/msg/detail/autoware_shutdown__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autoware_cawsr_msgs
{

namespace msg
{

namespace builder
{

class Init_AutowareShutdown_carla_map
{
public:
  Init_AutowareShutdown_carla_map()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::autoware_cawsr_msgs::msg::AutowareShutdown carla_map(::autoware_cawsr_msgs::msg::AutowareShutdown::_carla_map_type arg)
  {
    msg_.carla_map = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autoware_cawsr_msgs::msg::AutowareShutdown msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::autoware_cawsr_msgs::msg::AutowareShutdown>()
{
  return autoware_cawsr_msgs::msg::builder::Init_AutowareShutdown_carla_map();
}

}  // namespace autoware_cawsr_msgs

#endif  // AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__BUILDER_HPP_

// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autoware_cawsr_msgs:msg/AutowareShutdown.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__STRUCT_H_
#define AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'carla_map'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/AutowareShutdown in the package autoware_cawsr_msgs.
typedef struct autoware_cawsr_msgs__msg__AutowareShutdown
{
  rosidl_runtime_c__String carla_map;
} autoware_cawsr_msgs__msg__AutowareShutdown;

// Struct for a sequence of autoware_cawsr_msgs__msg__AutowareShutdown.
typedef struct autoware_cawsr_msgs__msg__AutowareShutdown__Sequence
{
  autoware_cawsr_msgs__msg__AutowareShutdown * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autoware_cawsr_msgs__msg__AutowareShutdown__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__STRUCT_H_

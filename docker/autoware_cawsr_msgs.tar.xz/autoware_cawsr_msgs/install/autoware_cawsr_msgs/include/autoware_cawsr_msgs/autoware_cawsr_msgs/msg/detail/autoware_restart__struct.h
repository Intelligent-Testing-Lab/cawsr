// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autoware_cawsr_msgs:msg/AutowareRestart.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_RESTART__STRUCT_H_
#define AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_RESTART__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'carla_map'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/AutowareRestart in the package autoware_cawsr_msgs.
typedef struct autoware_cawsr_msgs__msg__AutowareRestart
{
  rosidl_runtime_c__String carla_map;
} autoware_cawsr_msgs__msg__AutowareRestart;

// Struct for a sequence of autoware_cawsr_msgs__msg__AutowareRestart.
typedef struct autoware_cawsr_msgs__msg__AutowareRestart__Sequence
{
  autoware_cawsr_msgs__msg__AutowareRestart * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autoware_cawsr_msgs__msg__AutowareRestart__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_RESTART__STRUCT_H_

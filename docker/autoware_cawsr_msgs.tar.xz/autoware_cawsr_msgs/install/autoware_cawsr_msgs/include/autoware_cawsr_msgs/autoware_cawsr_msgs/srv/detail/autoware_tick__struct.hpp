// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from autoware_cawsr_msgs:srv/AutowareTick.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__STRUCT_HPP_
#define AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__autoware_cawsr_msgs__srv__AutowareTick_Request __attribute__((deprecated))
#else
# define DEPRECATED__autoware_cawsr_msgs__srv__AutowareTick_Request __declspec(deprecated)
#endif

namespace autoware_cawsr_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct AutowareTick_Request_
{
  using Type = AutowareTick_Request_<ContainerAllocator>;

  explicit AutowareTick_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    (void)_init;
  }

  explicit AutowareTick_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__autoware_cawsr_msgs__srv__AutowareTick_Request
    std::shared_ptr<autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__autoware_cawsr_msgs__srv__AutowareTick_Request
    std::shared_ptr<autoware_cawsr_msgs::srv::AutowareTick_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AutowareTick_Request_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    return true;
  }
  bool operator!=(const AutowareTick_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AutowareTick_Request_

// alias to use template instance with default allocator
using AutowareTick_Request =
  autoware_cawsr_msgs::srv::AutowareTick_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace autoware_cawsr_msgs


// Include directives for member types
// Member 'header'
// already included above
// #include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__autoware_cawsr_msgs__srv__AutowareTick_Response __attribute__((deprecated))
#else
# define DEPRECATED__autoware_cawsr_msgs__srv__AutowareTick_Response __declspec(deprecated)
#endif

namespace autoware_cawsr_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct AutowareTick_Response_
{
  using Type = AutowareTick_Response_<ContainerAllocator>;

  explicit AutowareTick_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->snapshot = 0.0f;
      this->state = 0.0f;
      this->sensor = 0.0f;
      this->control = 0.0f;
      this->agent_total = 0.0f;
    }
  }

  explicit AutowareTick_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->snapshot = 0.0f;
      this->state = 0.0f;
      this->sensor = 0.0f;
      this->control = 0.0f;
      this->agent_total = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _snapshot_type =
    float;
  _snapshot_type snapshot;
  using _state_type =
    float;
  _state_type state;
  using _sensor_type =
    float;
  _sensor_type sensor;
  using _control_type =
    float;
  _control_type control;
  using _agent_total_type =
    float;
  _agent_total_type agent_total;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__snapshot(
    const float & _arg)
  {
    this->snapshot = _arg;
    return *this;
  }
  Type & set__state(
    const float & _arg)
  {
    this->state = _arg;
    return *this;
  }
  Type & set__sensor(
    const float & _arg)
  {
    this->sensor = _arg;
    return *this;
  }
  Type & set__control(
    const float & _arg)
  {
    this->control = _arg;
    return *this;
  }
  Type & set__agent_total(
    const float & _arg)
  {
    this->agent_total = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__autoware_cawsr_msgs__srv__AutowareTick_Response
    std::shared_ptr<autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__autoware_cawsr_msgs__srv__AutowareTick_Response
    std::shared_ptr<autoware_cawsr_msgs::srv::AutowareTick_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AutowareTick_Response_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->snapshot != other.snapshot) {
      return false;
    }
    if (this->state != other.state) {
      return false;
    }
    if (this->sensor != other.sensor) {
      return false;
    }
    if (this->control != other.control) {
      return false;
    }
    if (this->agent_total != other.agent_total) {
      return false;
    }
    return true;
  }
  bool operator!=(const AutowareTick_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AutowareTick_Response_

// alias to use template instance with default allocator
using AutowareTick_Response =
  autoware_cawsr_msgs::srv::AutowareTick_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace autoware_cawsr_msgs

namespace autoware_cawsr_msgs
{

namespace srv
{

struct AutowareTick
{
  using Request = autoware_cawsr_msgs::srv::AutowareTick_Request;
  using Response = autoware_cawsr_msgs::srv::AutowareTick_Response;
};

}  // namespace srv

}  // namespace autoware_cawsr_msgs

#endif  // AUTOWARE_CAWSR_MSGS__SRV__DETAIL__AUTOWARE_TICK__STRUCT_HPP_

// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from autoware_cawsr_msgs:msg/AutowareShutdown.idl
// generated code does not contain a copyright notice

#ifndef AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "autoware_cawsr_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_autoware_cawsr_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autoware_cawsr_msgs, msg, AutowareShutdown)();

#ifdef __cplusplus
}
#endif

#endif  // AUTOWARE_CAWSR_MSGS__MSG__DETAIL__AUTOWARE_SHUTDOWN__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

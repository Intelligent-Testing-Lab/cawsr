^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package autoware_common_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.9.0 (2025-06-18)
------------------

1.8.0 (2025-05-21)
------------------
* chore: fix email domain (`#133 <https://github.com/autowarefoundation/autoware_msgs/issues/133>`_)
* chore: update maintainers (`#132 <https://github.com/autowarefoundation/autoware_msgs/issues/132>`_)
* Contributors: Mete Fatih Cırıt

1.7.0 (2025-04-21)
------------------

1.6.0 (2025-04-07)
------------------

1.5.0 (2025-04-02)
------------------

1.4.0 (2025-02-25)
------------------
* fix(autoware_msgs): fix links to issues in CHANGELOG.rst files (`#108 <https://github.com/autowarefoundation/autoware_msgs/issues/108>`_)
* Contributors: Esteve Fernandez

1.3.0 (2024-11-25)
------------------

1.2.0 (2024-10-01)
------------------

1.1.0 (2024-05-10)
------------------
* chore: update `package.xml` and fix `CMakeLists.txt` (`#91 <https://github.com/autowarefoundation/autoware_msgs/issues/91>`_)
  update package.xml and fix cmakefiles
* build: package.xml dependencies  (`#60 <https://github.com/autowarefoundation/autoware_msgs/issues/60>`_)
  * mark rosidl_default_generators as <build_depend>
  * add missing rosidl_default_runtime <exec_depend>
  ---------
* feat(autoware_common_msgs): add autoware common messages (`#37 <https://github.com/autowarefoundation/autoware_msgs/issues/37>`_)
  * feat(autoware_common_msgs): add autoware common messages
  * fix: fix dependency
* Contributors: Takagi, Isamu, Vincent Richard, Yutaka Kondo
